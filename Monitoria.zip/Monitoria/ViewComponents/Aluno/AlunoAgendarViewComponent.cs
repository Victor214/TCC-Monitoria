﻿using Microsoft.AspNetCore.Mvc;
using Monitoria.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Monitoria.ViewComponents.Aluno
{
    public class AlunoAgendarViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke((Disciplina disciplina, Participante participante, Dictionary<DateTime, bool> horariosDisponiveisMonitor, List<(int, DateTime)> horariosTotais) model)
        {
            return View("AlunoAgendar", model);
        }
    }
}
