﻿using Microsoft.AspNetCore.Mvc;
using Monitoria.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Monitoria.ViewComponents.Aluno
{
    public class MonitorSidebarViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke(Disciplina disciplina)
        {
            return View("MonitorSidebar", disciplina);
        }
    }
}
