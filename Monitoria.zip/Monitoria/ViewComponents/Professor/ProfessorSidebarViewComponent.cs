﻿using Microsoft.AspNetCore.Mvc;
using Monitoria.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Monitoria.ViewComponents.Aluno
{
    public class ProfessorSidebarViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke(Disciplina disciplina)
        {
            return View("ProfessorSidebar", disciplina);
        }
    }
}
