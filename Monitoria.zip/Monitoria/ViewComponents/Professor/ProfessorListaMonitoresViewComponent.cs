﻿using Microsoft.AspNetCore.Mvc;
using Monitoria.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Monitoria.ViewComponents.Aluno
{
    public class ProfessorListaMonitoresViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke((Disciplina disciplina, Participante participante, List<Participante> monitores, List<Participante> alunos) model)
        {
            return View("ProfessorListaMonitores", model);
        }
    }
}
