﻿using Monitoria.Configs;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Monitoria.Util
{
    public static class DateUtil
    {
        public static List<DateTime> GetFiveNextBusinessDays()
        {
            var result = new List<DateTime>();
            for (int i = 0; i < 7; i++) {
                int dayOfweek = ((int)DateTime.Now.DayOfWeek + i) % 7; 
                if (dayOfweek == (int)DayOfWeek.Saturday || dayOfweek == (int)DayOfWeek.Sunday)
                    continue;

                result.Add(DateTime.Now.AddDays(i));
            }
            return result;
        }

        public static bool IsSameDay(DateTime a, DateTime b)
        {
            if (a.Day == b.Day && a.Month == b.Month && a.Year == b.Year)
                return true;
            return false;
        }

        public static bool IsToday(DateTime a)
        {
            return IsSameDay(DateTime.Now, a);
        }

        private static readonly CultureInfo Culture = new CultureInfo("pt-BR");
        public static string GetDayOfWeekAbbr(DateTime time)
        {
            return Culture.DateTimeFormat.AbbreviatedDayNames[(int)time.DayOfWeek];
        }

        public static string GetMonthAbbr(DateTime time)
        {
            return Culture.DateTimeFormat.GetAbbreviatedMonthName(time.Month);
        }

        public static string GetMonthName(DateTime time)
        {
            return Culture.DateTimeFormat.GetMonthName(time.Month);
        }

        public static string GetDayOfWeekName(DateTime time)
        {
            return Culture.DateTimeFormat.GetDayName(time.DayOfWeek);
        }

        public static bool IsHorarioAvailable(DateTime date, DateTime time, Dictionary<DateTime, bool> horariosDisponiveisMonitor)
        {
            var dateTime = new DateTime(date.Year, date.Month, date.Day, time.Hour, time.Minute, time.Second);
            return horariosDisponiveisMonitor.ContainsKey(dateTime);
        }

        public static string CombineDayTimeAsString(DateTime date, DateTime time)
        {
            return $"{date.Year}|{date.Month}|{date.Day}|{time.Hour}|{time.Minute}|{time.Second}";
        }

        public static int GetHorarioValid(DateTime horarioDateTime)
        {
            var startingTime = TurnoConfigs.GetStartingTime();
            var sessionDuration = TurnoConfigs.GetSessionDuration();
            var totalSessions = TurnoConfigs.GetTotalDailySessions();

            for (int i = 1; i <= totalSessions; i++) {
                var session = new DateTime(horarioDateTime.Year, horarioDateTime.Month, horarioDateTime.Day, startingTime[0], startingTime[1], 0).AddMinutes((i - 1) * sessionDuration);
                if (session == horarioDateTime)
                    return i;
            }

            return -1;
        }
    }
}
