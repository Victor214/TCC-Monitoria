﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitoria.Configs
{
    public static class TurnoConfigs
    {

        public static Dictionary<string, int> GetShiftStartingIndexes()
        {
            return Startup.StaticConfiguration.GetSection("ShiftStarts")
                          .Get<Dictionary<string, int>>()
                          .OrderBy(x => x.Value)
                          .ToDictionary(x => x.Key, x => x.Value);
        }

        public static int GetTotalDailySessions()
        {
            return int.Parse(Startup.StaticConfiguration["TotalDailySessions"]);
        }

        public static Dictionary<string, int> GetShiftTotalSessions()
        {
            var shiftStarts = GetShiftStartingIndexes();
            var totalSessions = GetTotalDailySessions();
            return new Dictionary<string, int>()
            {
                { "Morning", shiftStarts["Afternoon"]-shiftStarts["Morning"] },
                { "Afternoon", shiftStarts["Night"]-shiftStarts["Afternoon"] },
                { "Night", totalSessions - shiftStarts["Night"] + 1 },
            };
        }

        public static Dictionary<int, bool> GetUnavailableSessions()
        {
            return Startup.StaticConfiguration.GetSection("UnavailableSessions")
                                              .Get<List<int>>()
                                              .ToDictionary(x => x, x => false);
        }

        public static int[] GetStartingTime()
        {
            return Startup.StaticConfiguration.GetSection("StartingSessionTime")
                                              .Get<int[]>();
        }

        public static int GetSessionDuration()
        {
            return Startup.StaticConfiguration.GetSection("SessionDuration")
                                              .Get<int>();
        }
    }
}
