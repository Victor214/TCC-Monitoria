using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.Configuration;

namespace Monitoria.Pages
{
    [Authorize]
    public class LogoutModel : PageModel
    {
        private readonly IConfiguration Configuration;

        public LogoutModel(IConfiguration config)
        {
            this.Configuration = config;
        }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            return await LogoutHelper.Logout(this, HttpContext, Configuration, TempData);
        }


    }

    public static class LogoutHelper
    {
        public static async Task<IActionResult> Logout(PageModel page, HttpContext context, IConfiguration configuration, ITempDataDictionary tempData, bool isError=false)
        {
            await context.SignOutAsync(configuration["AuthName"]);
            tempData["LoggingOut"] = true;
            tempData["LoggingOutIsError"] = isError;
            return page.RedirectToPage("/Index");
        }
    }
}
