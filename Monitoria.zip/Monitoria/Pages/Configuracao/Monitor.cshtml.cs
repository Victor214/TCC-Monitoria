using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Monitoria.Configs;
using Monitoria.Core;
using Monitoria.Core.Enum;
using Monitoria.Data.Interface;

namespace Monitoria.Pages.Configuracao
{
    [Authorize]
    public class MonitorModel : PageModel
    {
        private IConfiguration configuration;

        private readonly IUsuarioData usuarioData;
        private readonly ISessaoMonitorData sessaoMonitorData;

        public MonitorModel(IConfiguration _configuration, IUsuarioData _usuarioData, ISessaoMonitorData _sessaoMonitorData)
        {
            configuration = _configuration;
            usuarioData = _usuarioData;
            sessaoMonitorData = _sessaoMonitorData;
        }
        public Dictionary<string, List<(int Indice, DateTime Horario)>> Horarios = new Dictionary<string, List<(int Indice, DateTime Horario)>>();
        public Dictionary<(int DayOfWeek, int Index), bool> HorariosMarcados = new Dictionary<(int DayOfWeek, int Index), bool>();

        [BindProperty]
        public string PreviousShift { get; set; }


        public async Task<IActionResult> OnGetAsync()
        {
            PreviousShift = (string)TempData["PreviousShift"] ?? "Morning";

            var ShiftStarts = TurnoConfigs.GetShiftStartingIndexes();
            var turnosSessions = TurnoConfigs.GetShiftTotalSessions();
            var unavailableSessions = TurnoConfigs.GetUnavailableSessions();
            var startingTime = TurnoConfigs.GetStartingTime();
            var sessionDuration = TurnoConfigs.GetSessionDuration();

            foreach (var turnoStarts in ShiftStarts)
            {
                var AvailableSessions = new List<(int, DateTime)>();
                for (int i = turnoStarts.Value; i < (turnoStarts.Value + turnosSessions[turnoStarts.Key]); i++)
                {
                    if (unavailableSessions.ContainsKey(i))
                        continue;

                    var session = new DateTime(1, 1, 1, startingTime[0], startingTime[1], 0).AddMinutes((i - 1) * sessionDuration);
                    AvailableSessions.Add((i, session));
                }
                Horarios.Add(turnoStarts.Key, AvailableSessions);
            }

            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            HorariosMarcados = sessaoMonitorData.GetUserSessoesMonitor(user);

            return Page();
        }
         
        public async Task<IActionResult> OnPostAddSessaoAsync(int Index, int DayOfWeek)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            var sessaoMonitor = new SessaoMonitor
            {
                Usuario = user,
                Indice = Index,
                DiaSemana = (DayOfWeek)DayOfWeek
            };

            var addedSessaoMonitor = sessaoMonitorData.AddSessao(sessaoMonitor);
            if (addedSessaoMonitor == null)
            {
                TempData["SessionNotAdded"] = true;
                return RedirectToPage();
            }
            sessaoMonitorData.Commit();

            TempData["PreviousShift"] = PreviousShift;
            return RedirectToPage();
        } 

        public async Task<IActionResult> OnPostDeleteSessaoAsync(int Index, int DayOfWeek)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            var sessaoMonitor = new SessaoMonitor
            {
                Usuario = user,
                Indice = Index,
                DiaSemana = (DayOfWeek)DayOfWeek
            };

            var removedSessaoMonitor = sessaoMonitorData.DeleteSessao(sessaoMonitor);
            if (removedSessaoMonitor == null) {
                TempData["SessionNotDeleted"] = true;
                return RedirectToPage();
            }
            sessaoMonitorData.Commit();

            TempData["PreviousShift"] = PreviousShift;
            return RedirectToPage();
        }
    }
}
