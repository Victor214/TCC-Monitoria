using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Monitoria.Core;
using Monitoria.Core.Enum;
using Monitoria.Data.Interface;

namespace Monitoria.Pages.Configuração
{
    [Authorize]
    public class PerfilModel : PageModel
    {
        private static IConfiguration configuration;
        private readonly IUsuarioData usuarioData;
        private readonly IContatoData contatoData;
        public PerfilModel(IConfiguration _configuration, IUsuarioData _usuarioData, IContatoData _contatoData)
        {
            configuration = _configuration;
            usuarioData = _usuarioData;
            contatoData = _contatoData;
        }

        [BindProperty(SupportsGet = true)]
        public int MaxContatos { get => int.Parse(configuration["MaxContatos"]); }
        public async Task<IActionResult> OnGetAsync()
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null)
            {
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);
            }

            Contatos = LoadContatos(user);
            return Page();
        }

        
        [BindProperty]
        public List<Contato> Contatos { get; set; }

        public async Task<IActionResult> OnPostContatosAsync()
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            if (Contatos.Any(c => c.Tipo == TipoContato.Email)) // None of the types can be emails
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            TipoContato minTipo = Enum.GetValues(typeof(TipoContato)).Cast<TipoContato>().Min();
            TipoContato maxTipo = Enum.GetValues(typeof(TipoContato)).Cast<TipoContato>().Max();
            if (Contatos.Any(c => c.Tipo < minTipo || c.Tipo > maxTipo)) // Types exceed the min and maximum
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            bool repeatingType = Contatos.Where(c => c.Valor != null)
                                         .GroupBy(c => c.Tipo)
                                         .Any(g => g.Count() > 1);
            if (repeatingType) // Type is repeating
            {
                TempData["RepeatingType"] = true;
                return RedirectToPage();
            }

            var unchangedContacts = contatoData.GetUserContacts(user).Where(c => c.Tipo != TipoContato.Email).ToList();
            int dbCount = unchangedContacts.Count()+1;
            foreach (var contato in Contatos)
            {
                // Should still move forward even if contato.Valor is empty, as it can be deleting a contact type.

                bool existingContact = contatoData.doesUserHasContact(user, contato);
                if (existingContact) // Not updated
                {
                    unchangedContacts.Remove(contato); // Remove from the pool of contacts that can be updated.
                    continue;
                }

                
                // Updating
                var contactToUpdate = unchangedContacts.FirstOrDefault(c => c.Tipo == contato.Tipo) ?? // Same type update regardless of how many contacts user has
                                      (!IsAdded(dbCount) ? unchangedContacts.FirstOrDefault() : null); // Different type update only if he has reached max contacts
                if (contactToUpdate != null)
                {
                    // If contato.Valor == null => Delete from DB

                    contactToUpdate.CopyData(contato);
                    contatoData.UpdateContact(contactToUpdate);
                    contatoData.Commit();
                    unchangedContacts.Remove(contactToUpdate);
                    continue;
                }

                // Adding
                if (IsAdded(dbCount))
                {
                    if (contato.Valor == null) // Adding an empty contact doesn't make sense.
                        continue;

                    contato.Id = 0;
                    contato.Usuario = user;
                    var addedContact = contatoData.AddContact(contato);
                    contatoData.Commit();
                    dbCount++;
                    // No need to remove from unchanged contacts as the query was made before this contact was added.
                    continue;
                }
            }

            TempData["Updated"] = true;
            return RedirectToPage();
        }


        private bool IsAdded(int dbCount)
        {
            return dbCount < MaxContatos;
        }

        private List<Contato> LoadContatos(Usuario user)
        {
            List<Contato> contatos = contatoData.GetUserContacts(user).Where(c => c.Tipo != TipoContato.Email).ToList();
            var filler = Enumerable.Range(contatos.Count, MaxContatos - contatos.Count).Select(x => new Contato());
            contatos.AddRange(filler);
            return contatos;
        }
    }
}
