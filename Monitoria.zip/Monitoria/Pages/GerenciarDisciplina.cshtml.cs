using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Monitoria.Core;
using Monitoria.Core.Enum;
using Monitoria.Data.Interface;

namespace Monitoria.Pages
{
    [Authorize]
    public class GerenciarDisciplinaModel : PageModel
    {
        private readonly IConfiguration configuration;
        private readonly IDisciplinaData disciplinaData;
        private readonly IUsuarioData usuarioData;

        public GerenciarDisciplinaModel(IDisciplinaData disciplinaData, IUsuarioData usuarioData, IConfiguration configuration)
        {
            this.disciplinaData = disciplinaData;
            this.usuarioData = usuarioData;
            this.configuration = configuration;
        }

        public IActionResult OnGet()
        {
            return RedirectToPage("/Dashboard");
        }

        public async Task<IActionResult> OnPostCreateSubjectAsync(Disciplina disciplina)
        {
            if (!ModelState.IsValid) {
                TempData["InvalidModelError"] = true;
                return RedirectToPage("/Dashboard");
            }

            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            disciplina.Criador = user;
            disciplina = disciplinaData.AddDisciplina(disciplina);
            var participante = disciplinaData.AddParticipante(disciplina, user, TipoUsuario.Professor);
            disciplinaData.Commit();

            TempData["SubjectAddedMessage"] = true;
            TempData["SubjectCode"] = disciplina.Codigo;
            return RedirectToPage("/Dashboard");
        }

        public async Task<IActionResult> OnPostEnterSubjectAsync(string code)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            Disciplina disciplina = disciplinaData.GetDisciplinaByCode(code);
            if (disciplina == null) { // Subject doesn't exist
                TempData["InvalidCodeError"] = true;
                return RedirectToPage("/Dashboard");
            }

            if (disciplinaData.IsUserInDisciplina(disciplina, user)) { // User already in the given subject
                TempData["UserAlreadyInSubjectError"] = true;
                return RedirectToPage("/Dashboard");
            }

            disciplinaData.AddParticipante(disciplina, user, TipoUsuario.Aluno);
            disciplinaData.Commit();

            return Redirect($"~/Disciplina/{code}");
        }
    }
}
