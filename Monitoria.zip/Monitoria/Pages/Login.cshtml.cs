using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Google.Apis.Auth;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Monitoria.Core;
using Monitoria.Core.Enum;
using Monitoria.Data.Interface;

namespace Monitoria.Pages
{
    public class LoginModel : PageModel
    {
        private readonly IUsuarioData usuarioData;
        private readonly IContatoData contatoData;
        private readonly IConfiguration Configuration;

        public LoginModel(IConfiguration config, IUsuarioData usuarioData, IContatoData contatoData)
        {
            this.Configuration = config;
            this.usuarioData = usuarioData;
            this.contatoData = contatoData;
        }

        public IActionResult OnGet()
        {
            // If (there's an existing session) then redirect to dashboard.
            if (HttpContext.User.Identity.IsAuthenticated)
                return RedirectToPage("/Dashboard");
            return Page();
        }

        [BindProperty]
        public String idtoken { get; set; }
        public int LoginResult { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            /*
            validPayload.Subject; // ID
            validPayload.Name; // Name
            validPayload.Email; // Email
            validPayload.Picture; // Picture Link  
            */

            var validPayload = await GoogleJsonWebSignature.ValidateAsync(idtoken);
            if (validPayload == null)
            {
                LoginResult = -1; // Error -1: Invalid token
                return Page(); // As soon as the page loads client-side, a signOut request shall be issued.
            }

            // Check if the user is already in the database, and if not, create an account for him.
            if (usuarioData.GetUserBySubject(validPayload.Subject) == null)
            {
                Usuario user = new Usuario
                {
                    Subject = validPayload.Subject,
                    Name = validPayload.Name,
                    Email = validPayload.Email
                };
                usuarioData.AddUser(user);
                usuarioData.Commit();

                Contato contato = new Contato
                {
                    Tipo = TipoContato.Email,
                    Valor = validPayload.Email,
                    Usuario = user
                };
                contatoData.AddContact(contato);
                contatoData.Commit();
            }

            // Authentication into the system.
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, validPayload.Name),
                new Claim(ClaimTypes.Email, validPayload.Email),
                new Claim("Subject", validPayload.Subject)
            };


            String authName = Configuration["AuthName"];
            ClaimsIdentity identity = new ClaimsIdentity(claims, authName);
            ClaimsPrincipal principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(authName, principal);

            TempData["LoginResult"] = true;
            
            return RedirectToPage("./Dashboard");

        }
    }
}
