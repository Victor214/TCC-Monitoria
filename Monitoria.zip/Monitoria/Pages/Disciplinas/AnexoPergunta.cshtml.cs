using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Monitoria.Core;
using Monitoria.Core.Enum;
using Monitoria.Data.Interface;

namespace Monitoria.Pages
{
    public class AnexoPerguntaModel : PageModel
    {
        private readonly IUsuarioData usuarioData;
        private readonly IDisciplinaData disciplinaData;
        private readonly IPerguntaData perguntaData;
        private readonly IConfiguration configuration;

        public AnexoPerguntaModel(IDisciplinaData disciplinaData, IUsuarioData usuarioData, IConfiguration configuration, IPerguntaData perguntaData)
        {
            this.disciplinaData = disciplinaData;
            this.usuarioData = usuarioData;
            this.configuration = configuration;
            this.perguntaData = perguntaData;
        }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            AnexoPergunta anexo = perguntaData.GetAnexoPerguntaFromId(id, user);
            if (anexo == null)
                return NotFound();

            var file = Convert.FromBase64String(anexo.Content);
            return File(file, FormatoExtensions.GetFormatContentType(anexo.Formato));
        }
    }
}
