using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Monitoria.Configs;
using Monitoria.Core;
using Monitoria.Core.Enum;
using Monitoria.Data.Interface;
using Monitoria.Util;

namespace Monitoria.Pages.Disciplinas
{
    public class AgendarModel : PageModel
    {
        private readonly IUsuarioData usuarioData;
        private readonly IDisciplinaData disciplinaData;
        private readonly IHorarioData horarioData;
        private readonly IConfiguration configuration;

        public AgendarModel(IDisciplinaData disciplinaData, IUsuarioData usuarioData, IConfiguration configuration, IHorarioData horarioData)
        {
            this.disciplinaData = disciplinaData;
            this.usuarioData = usuarioData;
            this.configuration = configuration;
            this.horarioData = horarioData;
        }

        public Disciplina Disciplina;
        public Participante Participante;
        public Dictionary<DateTime, bool> HorariosDisponiveisMonitor;
        public List<(int, DateTime)> HorariosTotais = new List<(int, DateTime)>();

        public async Task<IActionResult> OnGetAsync(string code)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            Disciplina = disciplinaData.GetDisciplinaByCode(code);
            if (Disciplina == null)
                return NotFound();

            bool userNotRegistered = Disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user) == null;
            if (userNotRegistered)
                return Unauthorized();

            Participante = Disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user).Participante;
            HorariosDisponiveisMonitor = horarioData.GetAvailableTimes(Disciplina);

            // List of  indexes and date of current shift.
            var shiftStarts = TurnoConfigs.GetShiftStartingIndexes();
            var turnosSessions = TurnoConfigs.GetShiftTotalSessions();
            var unavailableSessions = TurnoConfigs.GetUnavailableSessions();
            var startingTime = TurnoConfigs.GetStartingTime();
            var sessionDuration = TurnoConfigs.GetSessionDuration();
            var turno = Disciplina.Turno.ToString();
            var turnoStarts = shiftStarts[Disciplina.Turno.ToString()];
            
            for (int i = turnoStarts; i < (turnoStarts + turnosSessions[turno]); i++) {
                if (unavailableSessions.ContainsKey(i))
                    continue;

                var session = new DateTime(1, 1, 1, startingTime[0], startingTime[1], 0).AddMinutes((i - 1) * sessionDuration);
                HorariosTotais.Add((i, session));
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAgendarHorarioAsync(string code, string datetime)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            var disciplina = disciplinaData.GetDisciplinaByCode(code);
            if (disciplina == null)
                return NotFound();

            bool userNotRegistered = disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user) == null;
            if (userNotRegistered)
                return Unauthorized();

            Participante participante = disciplina.DisciplinaUsuarios
                                                  .FirstOrDefault(du => du.UsuarioId == user.Id)?
                                                  .Participante;

            if (participante == null) { // User attempting to post to a subject that he doesn't belong to.
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);
            }

            if (participante.TipoUsuario != TipoUsuario.Aluno) // No permissions
                return Unauthorized();

            // Bad format
            DateTime horarioDateTime;
            if (!DateTime.TryParseExact(datetime, "yyyy|M|d|H|m|s", CultureInfo.InvariantCulture, DateTimeStyles.None, out horarioDateTime)) {
                return BadRequest();
            }

            // Given datetime doesn't match any session time
            int index = DateUtil.GetHorarioValid(horarioDateTime);
            if (index == -1) {
                return BadRequest();
            }

            bool isAlunoFree = horarioData.DoesUserHasTimeFreeGlobal(participante, horarioDateTime);
            if (!isAlunoFree) { // User trying to schedule horario already has that time busy somewhere
                TempData["AlunoBusy"] = true;
                return RedirectToPage();
            }

            // Check if index belongs to disciplina's turno.

            // Get Monitores with given index available.
            List<Participante> monitores = horarioData.GetMonitoresWithIndexAvailable(disciplina, horarioDateTime.DayOfWeek, index );

            Participante freeMonitor = null;
            foreach (var monitor in monitores) {
                bool isFree = horarioData.DoesUserHasTimeFreeGlobal(monitor, horarioDateTime); // Checks all subjects he has a monitor role to see if he has that time available.
                if (isFree) {
                    freeMonitor = monitor;
                    break;
                }
            }

            if (freeMonitor == null) {
                TempData["NoMonitorFound"] = true;
                return RedirectToPage();
            }

            Horario horario = new Horario
            {
                Time = horarioDateTime,
                Aluno = participante,
                Monitor = freeMonitor
            };
            horarioData.AddHorario(horario);
            horarioData.Commit();

            TempData["HorarioAdded"] = true;
            return RedirectToPage();
        }
    }
}
