using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Monitoria.Core;
using Monitoria.Core.Enum;
using Monitoria.Data.Interface;

namespace Monitoria.Pages.Disciplinas
{
    public class MonitoresModel : PageModel
    {
        private readonly IUsuarioData usuarioData;
        private readonly IDisciplinaData disciplinaData;
        private readonly IConfiguration configuration;

        public MonitoresModel(IDisciplinaData disciplinaData, IUsuarioData usuarioData, IConfiguration configuration)
        {
            this.disciplinaData = disciplinaData;
            this.usuarioData = usuarioData;
            this.configuration = configuration;
        }

        public Disciplina Disciplina;
        public Participante Participante;
        public List<Participante> Monitores;
        public List<Participante> Alunos;

        public async Task<IActionResult> OnGetAsync(string code)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            Disciplina = disciplinaData.GetDisciplinaByCode(code);
            if (Disciplina == null)
                return NotFound();

            bool userNotRegistered = Disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user) == null;
            if (userNotRegistered)
                return Unauthorized();

            Participante = Disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user).Participante;
            Monitores = disciplinaData.GetMonitores(Disciplina);
            Alunos = disciplinaData.GetAlunos(Disciplina);
            return Page();
        }

        public async Task<IActionResult> OnPostPromoteAlunoAsync(string code, int participanteId)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            var disciplina = disciplinaData.GetDisciplinaByCode(code);
            if (disciplina == null)
                return NotFound();

            bool userNotRegistered = disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user) == null;
            if (userNotRegistered)
                return Unauthorized();

            Participante participante = disciplina.DisciplinaUsuarios
                                                  .FirstOrDefault(du => du.UsuarioId == user.Id)?
                                                  .Participante;
            if (participante == null) { // User attempting to post to a subject that he doesn't belong to.
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);
            }

            if (participante.TipoUsuario != TipoUsuario.Professor) // No permissions
                return Unauthorized();

            if (participanteId == 0) {
                TempData["BlankParticipanteError"] = true;
                return RedirectToPage();
            }

            Participante alunoPromovido = disciplina.DisciplinaUsuarios
                                                    .FirstOrDefault(du => du.ParticipanteId == participanteId)?
                                                    .Participante;
            if (alunoPromovido == null) // Aluno a ser promovido n�o foi encontrado na disciplina
                return BadRequest();

            disciplinaData.UpdateParticipante(alunoPromovido, TipoUsuario.Monitor);
            disciplinaData.Commit();

            return RedirectToPage();
        }
    }
}
