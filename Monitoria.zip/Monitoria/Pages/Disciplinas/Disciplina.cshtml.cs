using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Monitoria.Core;
using Monitoria.Core.Enum;
using Monitoria.Data.Interface;

namespace Monitoria.Pages
{
    [Authorize]
    public class DisciplinaModel : PageModel
    {
        private readonly IUsuarioData usuarioData;
        private readonly IDisciplinaData disciplinaData;
        private readonly IPerguntaData perguntaData;
        private readonly IConfiguration configuration;

        public DisciplinaModel(IDisciplinaData disciplinaData, IUsuarioData usuarioData, IPerguntaData perguntaData, IConfiguration configuration)
        {
            this.disciplinaData = disciplinaData;
            this.usuarioData = usuarioData;
            this.perguntaData = perguntaData;
            this.configuration = configuration;
        }

        public Disciplina Disciplina;
        public Participante Participante;
        public List<Pergunta> PerguntasFixadas;

        public async Task<IActionResult> OnGetAsync(string code)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            Disciplina = disciplinaData.GetDisciplinaByCode(code);
            if (Disciplina == null)
                return NotFound();

            bool userNotRegistered = Disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user) == null;
            if (userNotRegistered)
                return Unauthorized();

            Participante = Disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user).Participante;
            PerguntasFixadas = perguntaData.GetPinnedPerguntas(Disciplina);
            return Page();
        }
    }
}
