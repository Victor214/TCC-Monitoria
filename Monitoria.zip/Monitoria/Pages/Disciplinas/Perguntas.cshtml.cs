using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Monitoria.Core;
using Monitoria.Core.Enum;
using Monitoria.Data.Interface;

namespace Monitoria.Pages
{
    [Authorize]
    public class PerguntasModel : PageModel
    {
        private readonly IUsuarioData usuarioData;
        private readonly IDisciplinaData disciplinaData;
        private readonly IPerguntaData perguntaData;
        private readonly IConfiguration configuration;
        

        public PerguntasModel(IDisciplinaData disciplinaData, IUsuarioData usuarioData, IConfiguration configuration, IPerguntaData perguntaData)
        {
            this.disciplinaData = disciplinaData;
            this.usuarioData = usuarioData;
            this.perguntaData = perguntaData;
            this.configuration = configuration;
        }

        public Disciplina Disciplina;
        public Participante Participante;
        public List<Pergunta> PerguntasNaoRespondidas;
        public List<Pergunta> PerguntasRespondidas;
        public List<Pergunta> PerguntasNaoRespondidasMonitor;
        public List<Pergunta> PerguntasRespondidasMonitor;

        public async Task<IActionResult> OnGetAsync(string code)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            Disciplina = disciplinaData.GetDisciplinaByCode(code);
            if (Disciplina == null)
                return NotFound();

            bool userNotRegistered = Disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user) == null;
            if (userNotRegistered)
                return Unauthorized();

            Participante = Disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user).Participante;

            PerguntasNaoRespondidas = perguntaData.GetUnansweredPerguntasAluno(Participante);
            PerguntasRespondidas = perguntaData.GetAnsweredPerguntasAluno(Participante);
            PerguntasNaoRespondidasMonitor = perguntaData.GetUnansweredPerguntasMonitor(Participante);
            PerguntasRespondidasMonitor = perguntaData.GetAnsweredPerguntasMonitor(Participante);

            return Page();
        }


        public async Task<IActionResult> OnPostPerguntaAsync(string message, IFormFile inputFile, bool isSenderHidden, string code)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            Disciplina disciplina = disciplinaData.GetDisciplinaByCode(code);
            if (disciplina == null) { // User attempting to post to a subject that doesn't exist.
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);
            }

            Participante participante = disciplina.DisciplinaUsuarios
                 .FirstOrDefault(du => du.UsuarioId == user.Id)?
                 .Participante;
            if (participante == null) { // User attempting to post to a subject that he doesn't belong to.
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);
            }

            // Message Size
            if (message == null || message.Length < 5 || message.Length > 140) {
                TempData["IrregularQuestionSize"] = true;
                return RedirectToPage();
            }

            // File Validation
            Formato? inputFileFormat = null;
            if (inputFile != null) {
                var ext = Path.GetExtension(inputFile.FileName).Substring(1);

                inputFileFormat = FormatoExtensions.GetAllowedFormat(ext);
                if (inputFileFormat == null) {
                    TempData["IrregularFileFormat"] = true;
                    return RedirectToPage();
                }

                if (inputFile.Length < 1 && inputFile.Length > (5 * 1024 * 1024)) {
                    TempData["IrregularFileSize"] = true;
                    return RedirectToPage();
                }
            }

            var pergunta = new Pergunta {
                PerguntaData = message,
                IsAnonima = isSenderHidden,
                Aluno = participante
            };
            perguntaData.AddPergunta(pergunta);
            perguntaData.Commit();

            if (inputFile != null) {
                var ms = new MemoryStream();
                inputFile.CopyTo(ms);

                pergunta.Anexos = new List<AnexoPergunta> {
                    new AnexoPergunta
                    {
                        Pergunta = pergunta,
                        Formato = inputFileFormat.Value,
                        Content = Convert.ToBase64String(ms.ToArray())
                    }
                };

                perguntaData.AddAnexos(pergunta.Anexos);
                perguntaData.Commit();
            }

            TempData["QuestionAdded"] = true;
            return RedirectToPage();
        }


        public async Task<IActionResult> OnPostRespostaPergunta(string code, int idPergunta, string resposta)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            Disciplina disciplina = disciplinaData.GetDisciplinaByCode(code);
            if (disciplina == null) { // User attempting to post to a subject that doesn't exist.
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);
            }

            Participante participante = disciplina.DisciplinaUsuarios
                 .FirstOrDefault(du => du.UsuarioId == user.Id)?
                 .Participante;
            if (participante == null) { // User attempting to post to a subject that he doesn't belong to.
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);
            }

            // User is not monitor
            if (participante.TipoUsuario != TipoUsuario.Monitor) {
                return Unauthorized();
            }

            Pergunta pergunta = perguntaData.GetPerguntaById(idPergunta);
            if (pergunta.Aluno.DisciplinaUsuario.DisciplinaId != disciplina.Id) { // Question doesn't belong to the subject
                return Unauthorized();
            }

            if (pergunta.MonitorId != null) {
                return Unauthorized();
            }

            if (resposta == null || resposta.Length < 3 || resposta.Length > 140) {
                TempData["InvalidAnswerSize"] = true;
                return RedirectToPage();
            }

            pergunta.Monitor = participante;
            pergunta.RespostaData = resposta;
            perguntaData.UpdatePergunta(pergunta);
            perguntaData.Commit();

            TempData["AnswerAdded"] = true;
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostPinAsync(string code, int idPergunta, bool setPinned)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            Disciplina disciplina = disciplinaData.GetDisciplinaByCode(code);
            if (disciplina == null) { // User attempting to post to a subject that doesn't exist.
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);
            }

            Participante participante = disciplina.DisciplinaUsuarios
                 .FirstOrDefault(du => du.UsuarioId == user.Id)?
                 .Participante;
            if (participante == null) { // User attempting to post to a subject that he doesn't belong to.
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);
            }

            // User is not monitor
            if (participante.TipoUsuario != TipoUsuario.Monitor) {
                return Unauthorized();
            }

            Pergunta pergunta = perguntaData.GetPerguntaById(idPergunta);
            if (pergunta.Aluno.DisciplinaUsuario.DisciplinaId != disciplina.Id) { // Question doesn't belong to the subject
                return Unauthorized();
            }

            if (pergunta.MonitorId == null) { // Question must be answered
                return Unauthorized();
            }

            if (pergunta.IsFixada == setPinned) {
                return BadRequest();
            }

            pergunta.IsFixada = setPinned;
            perguntaData.UpdatePergunta(pergunta);
            perguntaData.Commit();

            string pinData = setPinned ? "SetPinned" : "SetUnpinned";
            TempData[pinData] = true;
            return RedirectToPage();
        }
    }
}
