using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Monitoria.Core;
using Monitoria.Data.Interface;

namespace Monitoria.Pages.Disciplinas
{
    public class EncerrarModel : PageModel
    {
        private readonly IUsuarioData usuarioData;
        private readonly IDisciplinaData disciplinaData;
        private readonly IConfiguration configuration;

        public EncerrarModel(IDisciplinaData disciplinaData, IUsuarioData usuarioData, IConfiguration configuration)
        {
            this.disciplinaData = disciplinaData;
            this.usuarioData = usuarioData;
            this.configuration = configuration;
        }

        public Disciplina Disciplina;
        public Participante Participante;

        public async Task<IActionResult> OnGetAsync(string code)
        {
            string subject = ((ClaimsIdentity)User.Identity).FindFirst("Subject")?.Value;
            Usuario user = usuarioData.GetUserBySubject(subject);
            if (user == null) // User not found
                return await LogoutHelper.Logout(this, HttpContext, configuration, TempData, true);

            Disciplina = disciplinaData.GetDisciplinaByCode(code);
            if (Disciplina == null)
                return NotFound();

            bool userNotRegistered = Disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user) == null;
            if (userNotRegistered)
                return Unauthorized();

            Participante = Disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user).Participante;
            return Page();
        }
    }
}
