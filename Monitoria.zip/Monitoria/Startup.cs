using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Monitoria.Data;
using Monitoria.Data.Data;
using Monitoria.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Monitoria
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            StaticConfiguration = configuration;
        }

        public IConfiguration Configuration { get; }
        public static IConfiguration StaticConfiguration { get; private set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRazorPages();
            Dictionary<string, List<string>> ViewComponentsList = new Dictionary<string, List<string>>()
            {
                {"All", new List<string>() { 
                    "DisciplinaHeader",
                }},
                {"Aluno", new List<string>() {
                    "AlunoAgendar",
                    "AlunoListaMonitores",
                    "AlunoMeusHorarios",
                    "AlunoMural",
                    "AlunoPerguntas",
                    "AlunoSidebar",
                }},
            };
            services.AddMvc()
            .AddRazorOptions(options => {
                //foreach (var category in ViewComponentsList) {
                //    foreach (var view in category.Value) {
                //        options.PageViewLocationFormats.Add($"/Pages/Components/{category.Key}/{view}/{view}.cshtml");
                //    }
                //}

                options.PageViewLocationFormats.Add("/Pages/{0}.cshtml");
            });

            // Database Setup
            string connStr = Configuration.GetSection("MonitoriaDb")["ConnectionString"];
            services.AddDbContextPool<MonitoriaDbContext>(options =>
            {
                options.UseMySql(connStr, ServerVersion.AutoDetect(connStr));
            });

            services.AddScoped<IDbInit, SqlDbInit>();
            services.AddScoped<IUsuarioData, SqlUsuarioData>();
            services.AddScoped<IContatoData, SqlContatoData>();
            services.AddScoped<ISessaoMonitorData, SqlSessaoMonitorData>();
            services.AddScoped<IDisciplinaData, SqlDisciplinaData>();
            services.AddScoped<IPerguntaData, SqlPerguntaData>();
            services.AddScoped<IHorarioData, SqlHorarioData>();

            services.AddRazorPages();

            // Authentication Setup
            string authName = Configuration["AuthName"];
            services.AddAuthentication(authName)
            .AddCookie(authName, options => // Regular Authentication Setup
            {
                options.Cookie.Name = authName;
                options.LoginPath = "/Login";
            })
            .AddGoogle(options => // Google Authentication Setup
            {
                // Following microsoft's official documentation
                IConfigurationSection googleAuthNSection =
                    Configuration.GetSection("Authentication:Google");

                options.ClientId = googleAuthNSection["ClientId"];
                options.ClientSecret = googleAuthNSection["ClientSecret"];
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseNodeModules();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
            });

            var scopeFactory = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>();
            using (var scope = scopeFactory.CreateScope()) {
                var dbInitializer = scope.ServiceProvider.GetService<IDbInit>();
                dbInitializer.Initialize();
                dbInitializer.SeedData();
            }
        }
    }
}
