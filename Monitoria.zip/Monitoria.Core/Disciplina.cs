﻿using Monitoria.Core.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Monitoria.Core
{
    public class Disciplina
    {
        public int Id { get; set; }
        public string Codigo { get; set; }

        [Required]
        [MinLength(3)]
        [MaxLength(30)]
        public string Nome { get; set; }

        [Required]
        [MinLength(3)]
        [MaxLength(30)]
        public string Local { get; set; }
        
        [Required]
        public Turno Turno { get; set; }

        public Usuario Criador { get; set; } // Quem é o criador da disciplina

        // Imagem
        public int ImagemDisciplinaId { get; set; }
        public ImagemDisciplina ImagemDisciplina { get; set; }

        // Participantes
        public List<DisciplinaUsuario> DisciplinaUsuarios { get; set; }
    }
}
