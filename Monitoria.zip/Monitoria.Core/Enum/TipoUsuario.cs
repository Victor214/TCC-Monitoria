﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Core.Enum
{
    public enum TipoUsuario
    {
        Aluno = 0,
        Monitor = 1,
        Professor = 2
    }
}
