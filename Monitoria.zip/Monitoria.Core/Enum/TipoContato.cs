﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Core.Enum
{
    public enum TipoContato
    {
        Email = 0,
        MicrosoftTeams = 1,
        WhatsApp = 2,
        Discord = 3
    }

    public static class TipoContatoExtensions
    {
        private static Dictionary<TipoContato, string> tipoContatoIcons = new Dictionary<TipoContato, string>()
        {
            { TipoContato.Email, "mail" },
            { TipoContato.MicrosoftTeams, "group" },
            { TipoContato.WhatsApp, "phone_android" },
            { TipoContato.Discord, "sports_esports" },
        };

        public static string GetTipoContatoIcon(TipoContato tipoContato)
        {
            return tipoContatoIcons[tipoContato];
        }
    }
}
