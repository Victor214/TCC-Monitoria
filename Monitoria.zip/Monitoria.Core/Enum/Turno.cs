﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Core.Enum
{
    public enum Turno
    {
        Morning = 0,
        Afternoon = 1,
        Night = 2
    }


}
