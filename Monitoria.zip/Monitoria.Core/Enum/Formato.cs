﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Monitoria.Core.Enum
{
    public enum Formato
    {
        Png = 0,
        Jpg = 1,
        Pdf = 2,
        Docx = 3,
        Doc = 4
    }

    public static class FormatoExtensions {
        public static Formato? GetAllowedFormat(this string formato)
        {
            string casedFormat = formato[0].ToString().ToUpper() + formato.Substring(1, formato.Length - 1).ToLower();
            foreach (Formato f in System.Enum.GetValues(typeof(Formato))) {
                if (f.ToString() == casedFormat)
                    return f;
            }
            return null;
        }

        public static string GetAllowedFormatsHTML()
        {
            var formats = new List<string>();
            foreach (Formato f in System.Enum.GetValues(typeof(Formato))) {
                formats.Add("." + f.ToString().ToLower());
            }
            return string.Join(",", formats);
        }

        private static Dictionary<Formato, (bool isImage, bool isDocument, string contentType)> FormatInfo = new Dictionary<Formato, (bool isImage, bool isDocument, string contentType)>()
        {
            {Formato.Png,  (isImage: true, isDocument: false, contentType: "image/png") },
            {Formato.Jpg,  (isImage: true, isDocument: false, contentType: "image/jpeg") },
            {Formato.Pdf,  (isImage: false, isDocument: true, contentType: "application/pdf") },
            {Formato.Docx, (isImage: false, isDocument: true, contentType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document") },
            {Formato.Doc,  (isImage: false, isDocument: true, contentType: "application/msword") },
        };


        public static bool IsImage(Formato f)
        {
            return FormatInfo[f].isImage;
        }

        public static bool IsDocument(Formato f)
        {
            return FormatInfo[f].isDocument;
        }

        public static string GetFormatContentType(Formato f)
        {
            return FormatInfo[f].contentType;
        }
    }

}
