﻿using Monitoria.Core.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Core
{
    // Representa um aluno, monitor ou professor dentro de uma dada disciplina
    public class Participante
    {
        public int Id { get; set; }
        public TipoUsuario TipoUsuario { get; set; }


        public DisciplinaUsuario DisciplinaUsuario { get; set; } // Aponta para o par de usuario + disciplina correspondente
        public List<Pergunta> PerguntasAluno { get; set; }
        public List<Pergunta> PerguntasMonitor { get; set; }
        public List<Horario> HorariosAluno { get; set; }
        public List<Horario> HorariosMonitor { get; set; }
    }
}
