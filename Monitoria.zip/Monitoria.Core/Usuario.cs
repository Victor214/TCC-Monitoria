﻿using System;
using System.Collections.Generic;

namespace Monitoria.Core
{
    public class Usuario
    {
        // Informações de Login do Google
        public int Id { get; set; }
        public String Subject { get; set; }
        public String Name { get; set; }
        public String Email { get; set; }

        public List<Contato> Contatos { get; set; }
        public List<SessaoMonitor> SessoesMonitor { get; set; }
        public List<DisciplinaUsuario> DisciplinaUsuarios { get; set; }
    }
}
