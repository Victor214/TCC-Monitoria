﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Core
{
    public class SessaoMonitor
    {
        public int Id { get; set; }
        public int Indice { get; set; } // Corresponds to the given day's index.
        public DayOfWeek DiaSemana { get; set; } 

        public int UsuarioId { get; set; } 
        public Usuario Usuario { get; set; }

    }
}
