﻿using Monitoria.Core.Enum;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Monitoria.Core
{
    public class Contato : IEquatable<Contato>
    {
        public int Id { get; set; }
        public TipoContato Tipo { get; set; }
        public string Valor { get; set; }

        public int UsuarioId { get; set; }
        public Usuario Usuario { get; set; }



        public void CopyData(Contato contato)
        {
            this.Tipo = contato.Tipo;
            this.Valor = contato.Valor;
        }

        public override bool Equals(object obj)
        {
            return this.Equals(obj as Contato);
        }

        public bool Equals([AllowNull] Contato other)
        {
            if (other == null)
                return false;

            return (this.Tipo == other.Tipo) && (this.Valor == other.Valor);
        }
    }
}
