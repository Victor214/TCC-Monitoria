﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Core
{
    public class Horario
    {
        public int Id { get; set; }
        public DateTime Time { get; set; }

        public int AlunoId { get; set; }
        public Participante Aluno { get; set; }
        public int MonitorId { get; set; }
        public Participante Monitor { get; set; }

    }
}
