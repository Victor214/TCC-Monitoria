﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Core
{
    public class ImagemDisciplina
    {
        public int Id { get; set; }
        public string ImagemCard { get; set; }
        public string ImagemCapa { get; set; }

        public List<Disciplina> Disciplinas { get; set; }
    }
}
