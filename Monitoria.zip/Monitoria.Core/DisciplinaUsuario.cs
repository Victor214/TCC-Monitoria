﻿using Monitoria.Core.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Core
{
    public class DisciplinaUsuario
    {
        // Relationship (Many to Many)
        public int DisciplinaId { get; set; }
        public Disciplina Disciplina { get; set; }
        public int UsuarioId { get; set; }
        public Usuario Usuario { get; set; }

        // Relationship (One to One)
        public int ParticipanteId { get; set; }
        public Participante Participante { get; set; }
        
    }
}
