﻿using Monitoria.Core.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Core
{
    public class AnexoPergunta
    {
        public int Id { get; set; }
        public Formato Formato { get; set; }
        public string Content { get; set; }

        public int PerguntaId { get; set; }
        public Pergunta Pergunta { get; set; }
    }
}
