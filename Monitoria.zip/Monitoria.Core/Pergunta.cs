﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Monitoria.Core
{
    public class Pergunta
    {
        public int Id { get; set; }

        [Required]
        [MinLength(3)]
        [MaxLength(140)]
        public string PerguntaData { get; set; }
        public string RespostaData { get; set; }
        public bool IsFixada { get; set; } = false;
        public bool IsAnonima { get; set; }
        public List<AnexoPergunta> Anexos { get; set; }

        public int AlunoId { get; set; }
        public Participante Aluno { get; set; }

        
        public int? MonitorId { get; set; }
        public Participante Monitor { get; set; }
    }
}