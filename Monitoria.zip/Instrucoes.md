# Monitoria
Sistema de Auxílio a Monitoria UFPR - Guia de Instalação

---
### Instalações Base
* Visual Studio 2019
* .NET Core 3.1
* MySQL (8.0 Community Edition)
* Node.js (v14.17.4)
* Node Package Manager (NPM) (6.14.14)

---
### Passo a Passo
* Clonar o repositório atual a partir do Visual Studio.
* Entrar na solução "Monitoria.sln".
* Abrir a pasta raíz do projeto em linha de comando, e digitar a instrução `npm install`.
* Criar a database "monitoria" no banco de dados MySQL.
* Acrescentar as configurações base no User Secrets do Visual Studio, utilizando os comandos:
  * `dotnet user-secrets init`
  * `dotnet user-secrets set "MonitoriaDb:ConnectionString" "server=localhost; port=3306; database=monitoria; user=root; password={senha}; Persist Security Info=False; Connect Timeout=300"`
  * `dotnet user-secrets set "Authentication:Google:ClientSecret" "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"`
  * `dotnet user-secrets set "Authentication:Google:ClientId" "932625705099-51c50kvfl791uadatdnhb45s6q38fa7a.apps.googleusercontent.com"`
* Atualizar o esquema do banco de dados conforme a última migration, utilizando os comandos
  * `cd Monitoria.Data`
  * `dotnet ef --startup-project ..\Monitoria database update`
* Executar a solução. 
