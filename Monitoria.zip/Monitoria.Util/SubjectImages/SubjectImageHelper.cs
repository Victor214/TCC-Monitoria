﻿using Monitoria.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Monitoria.Util.SubjectImages
{
    public class SubjectImageHelper
    {
        private static string CardImagePath = Directory.GetParent(Directory.GetCurrentDirectory()).FullName + "\\Monitoria.Util\\SubjectImages\\CardImages";
        private static string CoverImagePath = Directory.GetParent(Directory.GetCurrentDirectory()).FullName + "\\Monitoria.Util\\SubjectImages\\CoverImages";

        public static List<ImagemDisciplina> GetSubjectImageFiles() {
            DirectoryInfo d = new DirectoryInfo(CardImagePath);
            var result = new List<ImagemDisciplina>();
            foreach (var file in d.GetFiles("*.png")) {
                int imgIndex = int.Parse(file.Name.Substring(0, file.Name.Length - 4));
                byte[] cardArray = System.IO.File.ReadAllBytes(file.FullName);
                byte[] coverArray = System.IO.File.ReadAllBytes($"{CoverImagePath}\\{file.Name}");

                string cardBase64 = Convert.ToBase64String(cardArray);
                string coverBase64 = Convert.ToBase64String(coverArray);
                result.Add(new ImagemDisciplina { 
                    Id = imgIndex,
                    ImagemCapa = coverBase64,
                    ImagemCard = cardBase64
                });
            }
            return result;
        }
    }
}
