﻿using Monitoria.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Data.Interface
{
    public interface ISessaoMonitorData
    {
        SessaoMonitor AddSessao(SessaoMonitor newSession);
        SessaoMonitor DeleteSessao(SessaoMonitor session);
        Dictionary<(int DayOfWeek, int Index), bool> GetUserSessoesMonitor(Usuario user);
        int Commit();
    }
}
