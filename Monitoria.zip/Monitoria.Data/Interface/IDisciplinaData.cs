﻿using Monitoria.Core;
using Monitoria.Core.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Data.Interface
{
    public interface IDisciplinaData
    {
        Disciplina AddDisciplina(Disciplina newDisciplina);
        (DisciplinaUsuario disciplinaUsuario, Participante participante) AddParticipante(Disciplina disciplina, Usuario usuario, TipoUsuario tipoUsuario);
        Participante UpdateParticipante(Participante participante, TipoUsuario tipoUsuario);
        Disciplina GetDisciplinaByCode(string code);
        List<Disciplina> GetRegisteredDisciplinas(Usuario user);
        List<Participante> GetAlunos(Disciplina disciplina);
        List<Participante> GetMonitores(Disciplina disciplina);
        bool IsUserInDisciplina(Disciplina disciplina, Usuario user);
        int Commit();
        
    }
}
