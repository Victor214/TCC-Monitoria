﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Data.Interface
{
    public interface IDbInit
    {
        void Initialize();

        void SeedData();
    }
}
