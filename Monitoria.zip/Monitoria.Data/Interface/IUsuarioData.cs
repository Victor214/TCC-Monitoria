﻿using Monitoria.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Data.Interface
{
    public interface IUsuarioData
    {
        Usuario GetUserBySubject(String subject); // Returns a user if there is one.
        Usuario AddUser(Usuario newUser); // Adds a new user onto the database.
        int GetCountOfUsers();
        int Commit();
    }
}
