﻿using Monitoria.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Data.Interface
{
    public interface IContatoData
    {
        Contato AddContact(Contato newContact);
        Contato UpdateContact(Contato contact);
        List<Contato> GetUserContacts(Usuario user);
        int GetUserContactsCount(Usuario user);
        bool doesUserHasContact(Usuario user, Contato contact);
        int Commit();
    }
}
