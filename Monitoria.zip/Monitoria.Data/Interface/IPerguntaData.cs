﻿using Monitoria.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Data.Interface
{
    public interface IPerguntaData
    {
        Pergunta AddPergunta(Pergunta pergunta);
        List<AnexoPergunta> AddAnexos(List<AnexoPergunta> anexos);
        List<Pergunta> GetUnansweredPerguntasAluno(Participante participante);
        List<Pergunta> GetAnsweredPerguntasAluno(Participante participante);
        List<Pergunta> GetUnansweredPerguntasMonitor(Participante participante);
        List<Pergunta> GetAnsweredPerguntasMonitor(Participante participante);
        AnexoPergunta GetAnexoPerguntaFromId(int id, Usuario user);
        Pergunta GetPerguntaById(int idPergunta);
        Pergunta UpdatePergunta(Pergunta pergunta);
        List<Pergunta> GetPinnedPerguntas(Disciplina disciplina);
        int Commit();
        
    }
}
