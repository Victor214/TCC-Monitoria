﻿using Monitoria.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace Monitoria.Data.Interface
{
    public interface IHorarioData
    {
        Horario AddHorario(Horario horario);
        List<Horario> GetFutureHorariosAluno(Participante participante);
        List<Horario> GetFutureHorariosMonitor(Participante participante);
        Dictionary<DateTime, bool> GetAvailableTimes(Disciplina disciplina);
        List<Participante> GetMonitoresWithIndexAvailable(Disciplina disciplina, DayOfWeek dayOfWeek, int index);
        bool DoesUserHasTimeFreeGlobal(Participante participante, DateTime horarioDateTime);
        int Commit();

    }
}
