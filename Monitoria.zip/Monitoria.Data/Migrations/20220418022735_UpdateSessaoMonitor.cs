﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Monitoria.Data.Migrations
{
    public partial class UpdateSessaoMonitor : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Index",
                table: "SessoesMonitor",
                newName: "Indice");

            migrationBuilder.AddColumn<int>(
                name: "DiaSemana",
                table: "SessoesMonitor",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DiaSemana",
                table: "SessoesMonitor");

            migrationBuilder.RenameColumn(
                name: "Indice",
                table: "SessoesMonitor",
                newName: "Index");
        }
    }
}
