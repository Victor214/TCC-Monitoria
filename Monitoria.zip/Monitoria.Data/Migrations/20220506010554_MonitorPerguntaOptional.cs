﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Monitoria.Data.Migrations
{
    public partial class MonitorPerguntaOptional : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Perguntas_Participantes_MonitorId",
                table: "Perguntas");

            migrationBuilder.AlterColumn<int>(
                name: "MonitorId",
                table: "Perguntas",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_Perguntas_Participantes_MonitorId",
                table: "Perguntas",
                column: "MonitorId",
                principalTable: "Participantes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Perguntas_Participantes_MonitorId",
                table: "Perguntas");

            migrationBuilder.AlterColumn<int>(
                name: "MonitorId",
                table: "Perguntas",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Perguntas_Participantes_MonitorId",
                table: "Perguntas",
                column: "MonitorId",
                principalTable: "Participantes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
