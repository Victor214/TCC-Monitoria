﻿using Monitoria.Core;
using Monitoria.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitoria.Data.Data
{
    public class SqlSessaoMonitorData : ISessaoMonitorData
    {
        private MonitoriaDbContext db;

        public SqlSessaoMonitorData(MonitoriaDbContext db)
        {
            this.db = db;
        }

        public SessaoMonitor AddSessao(SessaoMonitor newSession)
        {
            var repeatedSession = db.SessoesMonitor.FirstOrDefault(s => s.UsuarioId == newSession.Usuario.Id
                                                                     && s.DiaSemana == newSession.DiaSemana
                                                                     && s.Indice == newSession.Indice);
            if (repeatedSession != null)
                return null;

            db.SessoesMonitor.Add(newSession);
            return newSession;
        }

        public SessaoMonitor DeleteSessao(SessaoMonitor session)
        {
            var toDeleteSession = db.SessoesMonitor.FirstOrDefault(s => s.UsuarioId == session.Usuario.Id
                                                                     && s.DiaSemana == session.DiaSemana
                                                                     && s.Indice == session.Indice);
            if (toDeleteSession == null)
                return null;

            db.SessoesMonitor.Remove(toDeleteSession);
            return toDeleteSession;
        }

        public Dictionary<(int DayOfWeek, int Index), bool> GetUserSessoesMonitor(Usuario user)
        {
            return db.SessoesMonitor.Where(s => s.UsuarioId == user.Id)
                                    .ToDictionary(s => ((int) s.DiaSemana, s.Indice), s => true);
        }

        public int Commit()
        {
            return db.SaveChanges();
        }
    }
}
