﻿using Monitoria.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Monitoria.Data.Interface;

namespace Monitoria.Data.Data
{
    public class SqlUsuarioData : IUsuarioData
    {
        private MonitoriaDbContext db;

        public SqlUsuarioData(MonitoriaDbContext db)
        {
            this.db = db;
        }

        public Usuario AddUser(Usuario newUser)
        {
            db.Usuarios.Add(newUser);
            return newUser;
        }

        public int Commit()
        {
            return db.SaveChanges();
        }

        public int GetCountOfUsers()
        {
            return db.Usuarios.Count();
        }

        public Usuario GetUserBySubject(String subject)
        {
            var query = from user in db.Usuarios
                        where user.Subject == subject
                        select user;
            return query.FirstOrDefault();
        }
    }
}
