﻿using Monitoria.Core;
using Monitoria.Data.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Monitoria.Data.Data
{
    public class SqlContatoData : IContatoData
    {
        private MonitoriaDbContext db;

        public SqlContatoData(MonitoriaDbContext db)
        {
            this.db = db;
        }

        public Contato AddContact(Contato newContact)
        {
            db.Contatos.Add(newContact);
            return newContact;
        }

        public Contato UpdateContact(Contato updatedContact)
        {
            var entity = db.Contatos.Attach(updatedContact);
            entity.State = EntityState.Modified;
            return updatedContact;
        }

        public List<Contato> GetUserContacts(Usuario user)
        {
            return db.Contatos.AsNoTracking()
                              .Where(c => c.UsuarioId == user.Id)
                              .ToList();
        }

        public int GetUserContactsCount(Usuario user)
        {
            return db.Contatos.Count(c => c.UsuarioId == user.Id);
        }

        public bool doesUserHasContact(Usuario user, Contato contact)
        {
            return db.Contatos
                .Include(c => c.Usuario)
                .AsNoTracking()
                .AsEnumerable()
                .Any(c => c.Usuario == user && c.Equals(contact));
        }

        public int Commit()
        {
            return db.SaveChanges();
        }
    }
}
