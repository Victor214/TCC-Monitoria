﻿using Microsoft.EntityFrameworkCore;
using Monitoria.Core;
using Monitoria.Core.Enum;
using Monitoria.Data.Interface;
using Monitoria.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitoria.Data.Data
{
    public class SqlDisciplinaData : IDisciplinaData
    {
        private MonitoriaDbContext db;

        public SqlDisciplinaData(MonitoriaDbContext db)
        {
            this.db = db;
        }

        public Disciplina AddDisciplina(Disciplina newDisciplina)
        {
            string code = GetNewCode();
            newDisciplina.ImagemDisciplina = GetRandomImage();
            newDisciplina.Codigo = code;
            db.Disciplinas.Add(newDisciplina);
            return newDisciplina;
        }

        public (DisciplinaUsuario disciplinaUsuario, Participante participante) AddParticipante(Disciplina disciplina, Usuario usuario, TipoUsuario tipoUsuario)
        {
            var participante = new Participante
            {
                TipoUsuario = tipoUsuario
            };

            var disciplinaUsuario = new DisciplinaUsuario
            {
                Disciplina = disciplina,
                Usuario = usuario,
                Participante = participante
            };

            participante.DisciplinaUsuario = disciplinaUsuario;

            db.Participantes.Add(participante);
            db.DisciplinaUsuarios.Add(disciplinaUsuario);
            return (disciplinaUsuario, participante);
        }

        public Participante UpdateParticipante(Participante participante, TipoUsuario tipoUsuario)
        {
            participante.TipoUsuario = tipoUsuario;
            var entity = db.Participantes.Attach(participante);
            entity.State = EntityState.Modified;
            return participante;
        }

        public List<Disciplina> GetRegisteredDisciplinas(Usuario user)
        {
            return db.Disciplinas
                         .Include(d => d.Criador)
                         .Include(d => d.ImagemDisciplina)
                         .Include(d => d.DisciplinaUsuarios)
                            .ThenInclude(du => du.Participante)
                         .Include(d => d.DisciplinaUsuarios)
                            .ThenInclude(du => du.Usuario)
                         .Where(d => d.DisciplinaUsuarios.Any(du => du.Usuario == user)) // If any user in DisciplinaUsuario is our user, then include disciplina
                         .ToList();

            //var disciplina =
            //(from d in db.Disciplinas
            // join du in db.DisciplinaUsuarios on d.Id equals du.DisciplinaId
            // join p in db.Participantes on du.ParticipanteId equals p.Id
            // join i in db.ImagensDisciplina on d.ImagemDisciplinaId equals i.Id
            // where du.UsuarioId == user.Id
            // select new Tuple<Disciplina, Participante, ImagemDisciplina>(d, p, i).ToValueTuple())
            //   .ToList();

            //return disciplina;
        }

        public Disciplina GetDisciplinaByCode(string code)
        {
            return db.Disciplinas
                     .Include(d => d.Criador)
                     .Include(d => d.ImagemDisciplina)
                     .Include(d => d.DisciplinaUsuarios)
                        .ThenInclude(du => du.Participante)
                     .Include(d => d.DisciplinaUsuarios)
                        .ThenInclude(du => du.Usuario)
                     .FirstOrDefault(d => d.Codigo == code);
        }

        public List<Participante> GetAlunos(Disciplina disciplina)
        {
            return db.Participantes
                     .Include(p => p.DisciplinaUsuario)
                        .ThenInclude(du => du.Disciplina)
                     .Include(p => p.DisciplinaUsuario)
                        .ThenInclude(du => du.Usuario)
                     .Where(p => p.DisciplinaUsuario.Disciplina.Id == disciplina.Id)
                     .Where(p => p.TipoUsuario == TipoUsuario.Aluno)
                     .ToList();
        }

        public List<Participante> GetMonitores(Disciplina disciplina)
        {
            return db.Participantes
                     .Include(p => p.DisciplinaUsuario)
                        .ThenInclude(du => du.Disciplina)
                     .Include(p => p.DisciplinaUsuario)
                        .ThenInclude(du => du.Usuario)
                     .Where(p => p.DisciplinaUsuario.Disciplina.Id == disciplina.Id)
                     .Where(p => p.TipoUsuario == TipoUsuario.Monitor)
                     .ToList();
        }
        public bool IsUserInDisciplina(Disciplina disciplina, Usuario user)
        {
            return db.Participantes
                     .Include(p => p.DisciplinaUsuario)
                     .Where(p => p.DisciplinaUsuario.DisciplinaId == disciplina.Id)
                     .Any(p => p.DisciplinaUsuario.UsuarioId == user.Id);
        }


        private Disciplina GetShallowDisciplinaByCode(string code)
        {
             return db.Disciplinas.FirstOrDefault(d => d.Codigo == code);
        }

        private string GetNewCode()
        {
            string code;
            Disciplina disciplinaResult;
            {
                code = SubjectCodeGenerator.GetUniqueKey(5);
                disciplinaResult = GetShallowDisciplinaByCode(code);
            } while (disciplinaResult != null) ;
            return code;
        }

        private ImagemDisciplina GetRandomImage()
        {
            Random rand = new Random();
            int toSkip = rand.Next(0, db.ImagensDisciplina.Count());

            return db.ImagensDisciplina.Skip(toSkip)
                                       .Take(1)
                                       .FirstOrDefault();
        }

        public int Commit()
        {
            return db.SaveChanges();
        }
    }
}
