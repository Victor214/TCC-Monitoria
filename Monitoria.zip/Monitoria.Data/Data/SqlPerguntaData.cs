﻿using Microsoft.EntityFrameworkCore;
using Monitoria.Core;
using Monitoria.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitoria.Data.Data
{
    public class SqlPerguntaData : IPerguntaData
    {
        private MonitoriaDbContext db;

        public SqlPerguntaData(MonitoriaDbContext db)
        {
            this.db = db;
        }

        public Pergunta AddPergunta(Pergunta pergunta)
        {
            db.Perguntas.Add(pergunta);
            return pergunta;
        }

        public List<AnexoPergunta> AddAnexos(List<AnexoPergunta> anexos)
        {
            foreach (var anexo in anexos) {
                db.AnexosPergunta.Add(anexo);
            }
            return anexos;
        }

        public List<Pergunta> GetUnansweredPerguntasAluno(Participante participante)
        {
            return db.Perguntas
                     .Include(pg => pg.Anexos)
                     .Include(pg => pg.Aluno)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Disciplina)
                     .Where(p => p.AlunoId == participante.Id && p.MonitorId == null)
                     .ToList();
        }

        public List<Pergunta> GetAnsweredPerguntasAluno(Participante participante)
        {
            return db.Perguntas
                     .Include(pg => pg.Anexos)
                     .Include(pg => pg.Monitor)
                     .Include(pg => pg.Aluno)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Disciplina)
                     .Where(p => p.AlunoId == participante.Id && p.MonitorId != null)
                     .ToList();
        }

        public List<Pergunta> GetUnansweredPerguntasMonitor(Participante participante)
        {
            return db.Perguntas
                     .Include(pg => pg.Anexos)
                     .Include(pg => pg.Aluno)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Disciplina)
                     .Where(pg => pg.Aluno.DisciplinaUsuario.DisciplinaId == participante.DisciplinaUsuario.DisciplinaId)
                     .Where(pg => pg.MonitorId == null)
                     .ToList();
        }

        public List<Pergunta> GetAnsweredPerguntasMonitor(Participante participante)
        {
            return db.Perguntas
                     .Include(pg => pg.Anexos)
                     .Include(pg => pg.Monitor)
                     .Include(pg => pg.Aluno)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Disciplina)
                     .Include(pg => pg.Aluno)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Usuario)
                     .Include(pg => pg.Monitor)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Usuario)
                     .Where(p => p.MonitorId != null && p.MonitorId == participante.Id)
                     .ToList();
        }

        public AnexoPergunta GetAnexoPerguntaFromId(int id, Usuario user)
        {
            var anexo = db.AnexosPergunta
                          .Include(a => a.Pergunta)
                            .ThenInclude(pg => pg.Aluno) // This could be a problem if student leaves the subject. Pergunta should have a link to subject.
                                .ThenInclude(pt => pt.DisciplinaUsuario)
                                    .ThenInclude(du => du.Disciplina)
                          .FirstOrDefault(a => a.Id == id);

            var disciplinaId = anexo.Pergunta.Aluno.DisciplinaUsuario.Disciplina.Id;
            var disciplina = db.Disciplinas
                               .Include(d => d.DisciplinaUsuarios)
                               .FirstOrDefault(d => d.Id == disciplinaId);

            bool userNotRegistered = disciplina.DisciplinaUsuarios.FirstOrDefault(du => du.Usuario == user) == null;
            if (userNotRegistered) // User does not have permission to access this file.
                return null;

            return anexo;
        }
        public List<Pergunta> GetPinnedPerguntas(Disciplina disciplina)
        {
            return db.Perguntas
                     .Include(pg => pg.Anexos)
                     .Include(pg => pg.Monitor)
                     .Include(pg => pg.Aluno)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Disciplina)
                     .Include(pg => pg.Aluno)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Usuario)
                     .Include(pg => pg.Monitor)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Usuario)
                     .Where(pg => pg.Aluno.DisciplinaUsuario.DisciplinaId == disciplina.Id) // Current subject
                     .Where(pg => pg.MonitorId != null) // Answered question
                     .Where(pg => pg.IsFixada == true) // Pinned
                     .ToList();

        }

        public Pergunta GetPerguntaById(int idPergunta)
        {
            return db.Perguntas
                     .Include(pg => pg.Aluno)
                        .ThenInclude(p => p.DisciplinaUsuario)
                            .ThenInclude(du => du.Disciplina)
                     .FirstOrDefault(pg => pg.Id == idPergunta);
        }

        public Pergunta UpdatePergunta(Pergunta pergunta)
        {
            var entity = db.Perguntas.Attach(pergunta);
            entity.State = EntityState.Modified;
            return pergunta;
        }

        public int Commit()
        {
            return db.SaveChanges();
        }


    }
}
