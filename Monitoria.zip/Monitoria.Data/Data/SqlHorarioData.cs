﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Monitoria.Core;
using Monitoria.Core.Enum;
using Monitoria.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitoria.Data.Data
{
    public class SqlHorarioData : IHorarioData
    {
        private MonitoriaDbContext db;
        private readonly IConfiguration configuration;

        public SqlHorarioData(MonitoriaDbContext db, IConfiguration configuration)
        {
            this.db = db;
            this.configuration = configuration;
        }

        public Horario AddHorario(Horario horario)
        {
            db.Horarios.Add(horario);
            return horario;
        }

        public List<Horario> GetFutureHorariosAluno(Participante participante)
        {
            return db.Horarios
                     .Include(h => h.Aluno)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Disciplina)
                     .Include(h => h.Monitor)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Usuario)
                                .ThenInclude(u => u.Contatos)
                     .Where(h => h.AlunoId == participante.Id)
                     .Where(h => h.Time >= DateTime.Now)
                     .OrderBy(h => h.Time)
                     .ToList();
        }

        public List<Horario> GetFutureHorariosMonitor(Participante participante)
        {
            return db.Horarios
                     .Include(h => h.Aluno)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Disciplina)
                     .Include(h => h.Aluno)
                        .ThenInclude(pt => pt.DisciplinaUsuario)
                            .ThenInclude(du => du.Usuario)
                                .ThenInclude(u => u.Contatos)
                     .Where(h => h.MonitorId == participante.Id)
                     .Where(h => h.Time >= DateTime.Now)
                     .OrderBy(h => h.Time)
                     .ToList();
        }

        // Get superposition of all (monitor times - already scheduled for him)
        public Dictionary<DateTime, bool> GetAvailableTimes(Disciplina disciplina)
        { 

            // Get all session (datetime) for each monitor
            var HorarioDic =
                db.Participantes
                  .Include(p => p.DisciplinaUsuario)
                    .ThenInclude(du => du.Usuario)
                        .ThenInclude(u => u.SessoesMonitor)
                  .Where(p => p.DisciplinaUsuario.DisciplinaId == disciplina.Id)
                  .Where(p => p.TipoUsuario == TipoUsuario.Monitor)
                  .ToDictionary(p => p, 
                                p => p.DisciplinaUsuario
                                      .Usuario
                                      .SessoesMonitor
                                      .Select(s => GetTimeFromSessao(s))
                                      .ToList());

            // Get all scheduled horarios (datetime) for each monitor
            var ScheduledDic =
                db.Participantes
                  .Include(p => p.DisciplinaUsuario)
                  .Include(p => p.HorariosMonitor)
                  .Where(p => p.DisciplinaUsuario.DisciplinaId == disciplina.Id)
                  .Where(p => p.TipoUsuario == TipoUsuario.Monitor)
                  .ToDictionary(p => p, 
                                p => p.HorariosMonitor
                                      .Select(h => h.Time)
                                      .ToList());

            // Subtract both lists into a free time lists, and add not repeating ones onto the dictionary
            var result = new Dictionary<DateTime, bool>();
            foreach (var participanteEntry in HorarioDic) { 
                var participante = participanteEntry.Key;
                var FreeHorarioList = HorarioDic[participante].Except(ScheduledDic[participante]).ToList();
                foreach (var datetime in FreeHorarioList) {
                    if (!result.ContainsKey(datetime)) {
                        result.Add(datetime, true);
                    }
                }  
            }

            return result;
        }

        public List<Participante> GetMonitoresWithIndexAvailable(Disciplina disciplina, DayOfWeek dayOfWeek, int index)
        {
            return db.Participantes
                     .Include(p => p.DisciplinaUsuario)
                         .ThenInclude(p => p.Usuario)
                             .ThenInclude(u => u.SessoesMonitor)
                     .Where(p => p.DisciplinaUsuario.DisciplinaId == disciplina.Id)
                     .Where(p => p.TipoUsuario == TipoUsuario.Monitor)
                     .AsEnumerable()
                     .Where(p => DoesMonitorHasIndexAvailable(p, dayOfWeek, index))
                     .ToList();
        }

        private bool DoesMonitorHasIndexAvailable(Participante participante, DayOfWeek dayOfWeek, int index)
        {
            var sessionsMonitor = participante.DisciplinaUsuario.Usuario.SessoesMonitor.ToList();
            return sessionsMonitor.Any(s => s.DiaSemana == dayOfWeek && s.Indice == index);
        }

        public bool DoesUserHasTimeFreeGlobal(Participante participante, DateTime horarioDateTime)
        {
            Usuario user = participante.DisciplinaUsuario.Usuario;
            var alreadyHasTime = db.Horarios
                                   .Include(h => h.Aluno)
                                       .ThenInclude(p => p.DisciplinaUsuario)
                                   .Include(h => h.Monitor)
                                       .ThenInclude(p => p.DisciplinaUsuario)
                                   .Where(h => h.Monitor.DisciplinaUsuario.UsuarioId == user.Id || h.Aluno.DisciplinaUsuario.UsuarioId == user.Id)
                                   .Any(h => h.Time == horarioDateTime);

            return !alreadyHasTime;
        }


        private DateTime GetTimeFromSessao(SessaoMonitor s)
        {
            var startingTime = configuration.GetSection("StartingSessionTime").Get<int[]>();
            var sessionDuration = configuration.GetSection("SessionDuration").Get<int>();

            DateTime time = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, startingTime[0], startingTime[1], 0).AddMinutes((s.Indice - 1) * sessionDuration);
            if (DateTime.Now.DayOfWeek == s.DiaSemana && DateTime.Now > time) {
                time = time.AddDays(7);
            } else {
                int daysUntilDayOfWeek = ((int)s.DiaSemana - (int)time.DayOfWeek + 7) % 7;
                time = time.AddDays(daysUntilDayOfWeek);
            }
            return time;
        }



        public int Commit()
        {
            return db.SaveChanges();
        }


    }
}
