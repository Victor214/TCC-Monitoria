﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Monitoria.Data.Interface;
using Monitoria.Util.SubjectImages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitoria.Data.Data
{

    public class SqlDbInit : IDbInit
    {
        private readonly IServiceScopeFactory _scopeFactory;

        public SqlDbInit(IServiceScopeFactory scopeFactory)
        {
            this._scopeFactory = scopeFactory;
        }

        public void Initialize()
        {
            using (var serviceScope = _scopeFactory.CreateScope()) {
                using (var db = serviceScope.ServiceProvider.GetService<MonitoriaDbContext>()) {
                    db.Database.Migrate();
                }
            }
        }

        public void SeedData()
        {
            using (var serviceScope = _scopeFactory.CreateScope()) {
                using (var db = serviceScope.ServiceProvider.GetService<MonitoriaDbContext>()) {

                    db.Database.EnsureCreated();
                    var images = SubjectImageHelper.GetSubjectImageFiles();
                    foreach (var image in images) {
                        var imageDb = db.ImagensDisciplina.FirstOrDefault(i => i.Id == image.Id);
                        if (imageDb != null)
                            continue;

                        db.ImagensDisciplina.Add(image);
                        db.SaveChanges();
                    }
                    
                }
            }
        }
    }
}
