﻿using Microsoft.EntityFrameworkCore;
using Monitoria.Core;
using Monitoria.Util.SubjectImages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitoria.Data
{
    public class MonitoriaDbContext : DbContext
    {
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Contato> Contatos { get; set; }
        public DbSet<SessaoMonitor> SessoesMonitor { get; set; }
        public DbSet<Disciplina> Disciplinas { get; set; }
        public DbSet<ImagemDisciplina> ImagensDisciplina { get; set; }
        public DbSet<DisciplinaUsuario> DisciplinaUsuarios { get; set; }
        public DbSet<Participante> Participantes { get; set; }
        public DbSet<AnexoPergunta> AnexosPergunta { get; set; }
        public DbSet<Pergunta> Perguntas { get; set; }
        public DbSet<Horario> Horarios { get; set; }

        public MonitoriaDbContext(DbContextOptions<MonitoriaDbContext> options) : base(options)
        {}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Contato>()
                .HasOne(c => c.Usuario)
                .WithMany(u => u.Contatos)
                .HasForeignKey(c => c.UsuarioId);

            modelBuilder.Entity<SessaoMonitor>()
                .HasOne(s => s.Usuario)
                .WithMany(u => u.SessoesMonitor)
                .HasForeignKey(s => s.UsuarioId);

            modelBuilder.Entity<DisciplinaUsuario>()
                .HasKey(du => new { du.DisciplinaId, du.UsuarioId });
            modelBuilder.Entity<DisciplinaUsuario>()
                .HasOne(du => du.Disciplina)
                .WithMany(d => d.DisciplinaUsuarios)
                .HasForeignKey(du => du.DisciplinaId);
            modelBuilder.Entity<DisciplinaUsuario>()
                .HasOne(du => du.Usuario)
                .WithMany(u => u.DisciplinaUsuarios)
                .HasForeignKey(du => du.UsuarioId);

            modelBuilder.Entity<Participante>()
                .HasOne<DisciplinaUsuario>(p => p.DisciplinaUsuario)
                .WithOne(du => du.Participante)
                .HasForeignKey<DisciplinaUsuario>(du => du.ParticipanteId);

            modelBuilder.Entity<Disciplina>()
                .HasOne(d => d.ImagemDisciplina)
                .WithMany(i => i.Disciplinas)
                .HasForeignKey(d => d.ImagemDisciplinaId);

            // Pergunta / Anexo
            modelBuilder.Entity<AnexoPergunta>()
                .HasOne(a => a.Pergunta)
                .WithMany(p => p.Anexos)
                .HasForeignKey(a => a.PerguntaId);

            // Pergunta / Aluno e Monitor (Participante)
            modelBuilder.Entity<Pergunta>()
                .HasOne(pg => pg.Aluno)
                .WithMany(pt => pt.PerguntasAluno)
                .HasForeignKey(pg => pg.AlunoId);
            modelBuilder.Entity<Pergunta>()
                .HasOne(pg => pg.Monitor)
                .WithMany(pt => pt.PerguntasMonitor)
                .HasForeignKey(pg => pg.MonitorId)
                .IsRequired(false);

            // Horario / Aluno e Monitor
            modelBuilder.Entity<Horario>()
                .HasOne(h => h.Aluno)
                .WithMany(pt => pt.HorariosAluno)
                .HasForeignKey(h => h.AlunoId);
            modelBuilder.Entity<Horario>()
                .HasOne(h => h.Monitor)
                .WithMany(pt => pt.HorariosMonitor)
                .HasForeignKey(h => h.MonitorId);

        }

    }
}
